package com.stefanini.application;


import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("service")
public class ProjectApplication extends Application {

}
